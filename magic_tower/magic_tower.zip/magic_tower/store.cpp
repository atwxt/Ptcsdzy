#include "store.h"

store::store(QWidget *parent)
    : QWidget{parent}
{

}

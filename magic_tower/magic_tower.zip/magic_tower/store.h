#ifndef STORE_H
#define STORE_H

#include <QWidget>

class store : public QWidget
{
    Q_OBJECT
public:
    explicit store(QWidget *parent = nullptr);

signals:

};

#endif // STORE_H

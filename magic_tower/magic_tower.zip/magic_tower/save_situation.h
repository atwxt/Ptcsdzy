#ifndef SAVE_SITUATION_H
#define SAVE_SITUATION_H

class save_situation
{
public:
    save_situation();
};

#endif // SAVE_SITUATION_H

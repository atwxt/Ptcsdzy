#include "save_situation.h"
#include<stdio.h>
save_situation::save_situation()
{
    freopen("out.txt", "w", stdout);
    cout<<
}

#include "read_situation.h"

read_situation::read_situation()
{

}

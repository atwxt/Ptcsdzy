#ifndef READ_SITUATION_H
#define READ_SITUATION_H


class read_situation
{
public:
    read_situation();
};

#endif // READ_SITUATION_H
